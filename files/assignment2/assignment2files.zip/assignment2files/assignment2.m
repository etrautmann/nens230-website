%% NENS 230: Problem Set #2
%  Due: October 6th, 2015
%  YOUR NAME HERE (your email here)

clear % Good practice is to start with a clean workspace for a given analysis
%% 1) The Compound Action Potential
%  We'll make a recording of the compound action potential, and  graph it below:

% Load the actionpotential.mat data file
% (1 line)
% Recall that the syntax is 'load filename.mat' (but without quotes)
% load actionpotential.mat % uncomment this line to get yourself started

% Adjust the time vector so that (t == 0) is the first point at which the voltage changes
% (1 or 2 lines)
% Hint: You want to offset (i.e. subtract from) the time vector by the first time value when 
% the voltage first stops being equal to zero.

% Adjust the time vector so that it is in milliseconds as opposed to seconds
% (1 line)

% Make a plot on figure 1 of the recorded voltage vs. time.
% Label your axes appropriately, and turn the grid on
% (~6 lines)
figure(1);
% ... continue here

% Determine the minimum and maximum voltage recorded.
% (4 lines)

% Plot when these minimum and maximum happen
% (2 more lines)
hold on


% Display this information as output with fprintf -- format as you like as long
% as it's reasonable.
% (~2-4 lines)

%% 2) The Strength-Duration curve
%  We'll make a strength-duration curve of whether the nerve responds to increasingly long
%  stimulation, and  graph it below:

% Load the data from the file pulsedata.csv, skipping the first header line
% Hint for skipping lines: look at the documentation for csvread, and note
% what the optional second argument does.
% (1 line)

% Plot a strength duration curve on figure 2 of the strength/voltage (y-axis) vs. the duration (x-axis)
% Label your axes appropriately, and turn the grid on. Use circle markers and a solid line
% Don't forget to make a new figure using the figure command, or you'll mess up your first
% figure.
% (~6 lines)


%% 3) Conduction Velocity
%  We'll make four measurements of conduction velocity from the provided data
% (1 line)
% Warning: data is BIG. Don't try to print it to the screen, your command window
% will be covered with numbers. Call size( traces )   to get your bearings.
% Remember, size( ) returns [numRows, numColumns)

% find maximum indices
% (2 lines)
% Hint: Look up the behavior of the max() function if you provide it two
% output arguments. Also read about how it handles a matrix as input.

% estimate velocity
% (1 line)
% Hint: ./ is 'element-wise' division, which is what you want. You should
% get a length 4 vector. If you did / (no dot), you asked for a least squares
% regression and will have a single-element (scalar).

% compute the mean and standard deviation of our measurement
% (2 lines)

% Display this information as output with fprintf
% (1 to a few lines)

%% 4) Smoothing a Noisy Trace
% *** This problem is extra credit ***
% i.e. If you've never programmed before and worked long  to get
% through 1-3, feel free to not do this one.

% Make a noisy voltage trace by adding Gaussian noise
% (1 line)
% Hint: add random noise by adding randn( ) to voltage. 
% e.g., to generate a 1x3 vector of gaussian noise of std 5,
% use 5*randn(1,3)

% Smooth this voltage trace
% Hint: use the smooth( ) command
% (1 line)

% Make a plot of the two traces (noisy with a solid black line, smoothed with a dashed red line)
% (~6 lines) 
