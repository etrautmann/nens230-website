%% NENS 230: Problem Set #2
%  Due: October 7th, 2014
%  YOUR NAME HERE

%% 1) the Compound Action Potential

% Load the actionpotential.mat data file

% Adjust the time vector so that (t == 0) is the first point at which the voltage changes

% Adjust the time vector so that it is in milliseconds as opposed to seconds

% Make a plot on figure 1 of the recorded voltage vs. time.
% Label your axes appropriately, and turn the grid on

% Figure out the minimum and maximum voltage recorded.

% Display this as output with fprintf


%% 2) the Strength-Duration curve

% Load the data from the file pulsedata.csv, skipping the first header line

% Plot a strength duration curve on figure 2 of the strength/voltage (y-axis) vs. the duration (x-axis)
% Label your axes appropriately, and turn the grid on. Use circle markers and a solid line


%% 3) Conduction Velocity

% Load the recordings from separate electrodes from recordings.mat

% find maximum indices

% estimate velocity

% compute the mean and standard deviation of our measurement

% Display this information as output with fprintf

%% 4) Smoothing a noisy trace

% Make a noisy voltage trace by adding Gaussian noise

% Smooth this voltage trace

% Make a plot of the two traces (noisy with a solid black line, smoothed with a dashed red line)

