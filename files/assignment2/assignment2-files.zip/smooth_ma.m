% Alternative smoothing function
% Niru Maheswaranathan
% Tue Oct  2 18:38:46 2012
% Smooths a signal with a moving average filter of size n (defaults to a size of 5)
% xs = smooth_ma(x,n)

function xs = smooth_ma(x,n)

  % default to a window size of 5
  if nargin < 2
      n = 5;
  end

  % create an array to store the smoothed vector
  xs = zeros(size(x));

  % loop over the elements of the vector
  for j = 1:length(x)

      % if we are past the first n elements, average the previous n elements
      if j >= n
          xs(j) = mean(x(j-n+1:j));

      % if we are within the first n elements, average from the start of the array
      else
          xs(j) = mean(x(1:j));
      end
  end
