function [] = ex_multivariate_regression()
% FUNCTION [] = ex_multivariate_regression()
%
% NENS 230 lecture 9
% Example of multivariate linear regression, which regresses a multi-
% dimensional variable against the given predictors.
%
% (C) 2014 Benjamin Naecker bnaecker@stanford.edu

%% Load and munge data.
load flu;

% The flu dataset contains estimates of influenza-like illness from both
% Google and the Center for Diseas Control and Prevention, over the course
% of many weeks. These estimates cover particular regions of the US, as well
% as nationwide. For this problem, we assume that the regional values are
% linearly related to the national values. The multi-dimensional array we're
% using as our observations are these regional percentages, and our predictor
% variable is just the single national estimate.
predictor = flu.WtdILI;
observations = double(flu(:, 2 : end - 1));
[n, d] = size(observations);
X = cell(n, 1);
for obs_i = 1:n
	X{obs_i} = [eye(d) predictor(obs_i) .* eye(d)];
end

%% Perform multivariate linear regression
coeffs = mvregress(X, observations);
B = reshape(coeffs, [d, 2]);

%% Plot the data and the linear regressions
x = linspace(min(predictor), max(predictor), 100);
line_handles = plot(predictor, observations, 'o');
hold on;
for i = 1:d
	plot(x, B(i, 1) + B(i, 2) .* x, ...
		'Color', get(line_handles(i), 'Color'), ...
		'LineStyle', '-', ...
		'LineWidth', 1.5);
end
legend(flu.Properties.VarNames(:, 2 : end -1), ...
	'Location', 'NorthWest');
xlabel('National flu incidence', 'FontSize', 18);
ylabel('Regional flu incidence', 'FontSize', 18);
title(sprintf('Multiple regression between\nnational and regional flu incidences'), ...
	'FontSize', 24);
box off, grid on;
set(gca, 'TickDir', 'out', 'FontSize', 18);
