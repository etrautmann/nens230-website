function [] = ex_multiple_regress()
% FUNCTION [] = ex_multiple_regress()
%
% NENS 230 lecture 9
% Example of multiple linear regression.
%
% (C) 2014 Benjamin Naecker bnaecker@stanford.edu

%% Load the builtin 'carbig' dataset.
% This contains data about a large number of cars, including
% their weight and mileage.
load carbig;

%% Multiple linear regression.
% Let's imagine we have some hypothesis about the relationship
% between some of the car's features. In this case, we hypothesize
% that a car's mileage per gallon is linearly related to both its
% weight and its horsepower. So a heavier car or a larger engine
% both linearly affect the MPG.

% Construct the design matrix. Again, we add a column of ones here
% for a constant term.
X = [ones(size(Weight, 1), 1) Weight Horsepower];

% Perform the linear regression, using the 'regress' function.
% The function returns lots of information about the fit, but in
% this example, we only care about the coefficients: the offset
% and the slopes for the weight and horsepower.
coeffs = regress(MPG, X);

%% Show the original data
plot3(Weight, Horsepower, MPG, ...
	'LineStyle', 'none', ...
	'Marker', 'o', ...
	'Color', 'k');
xlabel('Weight', 'FontSize', 18);
ylabel('Horsepower', 'FontSize', 18);
zlabel('MPG', 'FontSize', 18);
hold on;

%% Plot the fitted regression surface
weight_vals = linspace(min(Weight), max(Weight), 100);
horse_vals = linspace(min(Horsepower), max(Horsepower), 100);
[xvals, yvals] = meshgrid(weight_vals, horse_vals);
mesh(xvals, yvals, coeffs(1) + coeffs(2) * xvals + coeffs(3) * yvals, ...
	'FaceAlpha', 0.5, ...
	'EdgeAlpha', 0.5);

% Pretty up the plot
grid on;
set(gca, 'TickDir', 'out', 'FontSize', 18);
title('Multiple linear regression', 'FontSize', 24);
view(46, 24);
