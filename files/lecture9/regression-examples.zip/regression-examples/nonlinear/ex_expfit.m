function est_prs = ex_expfit()
% FUNCTION est_prs = ex_expfit()
%
% NENS 230 lecture 9
% Example of fitting a decaying exponential using 'nlinfit'. Returns the
% estimated parameters.
%
% (C) Benjamin Naecker bnaecker@stanford.edu

%% Generate data
x = linspace(0.01, 5, 100);
true_prs = [5; 2];
sd = 0.25;

% The anonymous function 'modelfun' is where most of the magic here is
% happening. The fitting function 'nlinfit' expects x and y values from
% the data, but also a function that you believe describes the data. This
% function needs to take two arguments: (1) the parameters for the function
% to be fit, as an array; and (2) x-values at which the function should be
% evaluated. 'nlinfit' then repeatedly evaluates this function, changing the
% parameters slightly each time, until the best fit (in the least-squares 
% sense) parameters are found.
modelfun = @(beta, x) beta(1) .* exp(-beta(2) .* x);
y = modelfun(true_prs, x) + sd .* randn(size(x));

%% Use nlinfit to estimate the curve
prs0 = [1; 1];

% You must give 'nlinfit' a set of initial parameters. Depending on how 
% complicated your function is, these may be extremely important. Exponentials
% are relatively simple, and so 'nlinfit' should estimate the same parameters
% most of the time. But more complicated functions are highly sensitive
% to these initial guesses. This means two things. First, it's important to 
% pick the simplest function that you believe actually describes the data.
% And second, you should really make the initial guesses as good as you can.
est_prs = nlinfit(x, y, modelfun, prs0);

%% Plot points and nonlinear function estimate
plot(x, y, ...
	'Marker', 'o', ...
	'LineStyle', 'none', ...
	'Color', [0 0.2 0.7], ...
	'LineWidth', 1.5);
hold on;
plot(x, modelfun(est_prs, x), ...
	'LineWidth', 2, ...
	'Color', 'k');
legend({'Data', 'Exponential fit'});
set(gca, 'TickDir', 'out', 'FontSize', 18);
title('Using "nlinfit" to fit an exponential', 'FontSize', 24);
box off, grid on;
hold off;
