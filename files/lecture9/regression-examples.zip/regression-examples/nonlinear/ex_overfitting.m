function [] = ex_overfitting()
% FUNCTION [] = ex_overfitting()
%
% NENS 230 lecture 9
% Example of polynomial overfitting, and using lasso to correct.
%
% (C) 2014 Benjamin Naecker bnaecker@stanford.edu

%% Generate data from a relatively simple polynomial model (third order).
x = linspace(-5, 5, 100)';
true_params = [10; -15; 0; 1];
sd = 10;
X = [ones(size(x)), x, x.^2, x.^3];
y = X * true_params + sd * randn(size(x));

%% Fit a ridiculously over-complicated model.
% This results in the problem called 'over-fitting'. Essentially, this occurs
% when the fitted curve follows the data so closely that it thinks the
% noise is actually signal. This results in an *very* error metric on the
% data used to learn the model, but a large error on any new data.
overfit_order = 25;
[overfit_prs, s, mu] = polyfit(x, y, overfit_order);

%% Use LASSO to get a better fit.
% There are a large number of ways to get around the problem of overfitting.
% The two most common are cross-validation and regularization. In cross-validation,
% you actually learn a different model for different, non-overlapping subsets
% of the data, and then do some form of averaging or pooling across these smaller
% models. The method we use here is regularization, which essentially "penalizes"
% a model for being too complex. The LASSO (developed by a professor here at
% Stanford) does this penalizing by trying to force as many of the learned 
% coefficients as possible to be 0. Intuitively, this results in a simpler model,
% since we're not "allowed" to use a lot of those extra parameters that add
% complexity.
[regularized_prs, stats] = lasso(X, y);

%% Plot data, overfitted model, and regularized model.
overfit_X = ones(size(x, 1), overfit_order + 1);
for i = 2:overfit_order + 1
	overfit_X(:, i) = x.^i;
end
figure; hold on;
plot(x, y, ...
	'Marker', 'o', ...
	'LineStyle', 'none', ...
	'Color', [0 0.2 0.7], ...
	'LineWidth', 1.5);
plot(x, polyval(overfit_prs, x, [], mu), ...
	'LineStyle', '--', ...
	'Color', 'r', ...
	'LineWidth', 1.5);
plot(x, X * regularized_prs(:, 1), ...
	'LineStyle', '-', ...
	'Color', 'k', ...
	'LineWidth', 1.5);
box off; grid on;
set(gca, 'TickDir', 'out', 'FontSize', 18);
title(sprintf(['Overfitted polynomial (mse = %0.2g)\n' ...
	'Regularized linear regression (mse = %0.2g)'], ...
	s.normr, stats.MSE(1)), ...
	'FontSize', 24);
hold off;

%% Show how the overfitted polynomial fails *wildly* outside the data bounds
figure; hold on;
plot(x, y, ...
	'Marker', 'o', ...
	'LineStyle', 'none', ...
	'Color', [0 0.2 0.7], ...
	'LineWidth', 3);
x2 = linspace(5, 5.1, 5)';
plot([x; x2], polyval(overfit_prs, [x; x2], [], mu), ...
	'LineStyle', '--', ...
	'Color', 'r', ...
	'LineWidth', 1.5);
box off; grid on;
set(gca, 'TickDir', 'out', 'FontSize', 18);
title('The consequences of overfitting', 'FontSize', 24);
hold off;
