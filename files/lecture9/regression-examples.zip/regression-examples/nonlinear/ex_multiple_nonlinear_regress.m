function [] = ex_multiple_nonlinear_regress()
% FUNCTION [] = ex_multiple_nonlinear_regress()
%
% NENS 230 lecture 9
% Example of multiple nonlinear regression.
%
% (C) 2014 Benjamin Naecker bnaecker@stanford.edu

%% Load the builtin 'carbig' dataset.
% This contains data about a large number of cars, including
% their weight and mileage.
load carbig;

%% Multiple linear regression.
% In the previous example using the 'regress' function, we assumed
% there was a purely linear relationship between a car's mileage and
% its weight and horsepower. But even if that relationship is nonlinear,
% we can still use the regress function to capture some of those simpler
% nonlinear relationships. For example, there may be interaction terms,
% such as the product of the weight and horsepower, to which the mileage
% is linearly related. To perform this type of regression, we simply 
% construct a more complicated design matrix. Everything else is the same.

% Construct the design matrix. Again, we add a column of ones here
% for a constant term. Also add the interaction term.
linear_X = [ones(size(Weight, 1), 1) Weight Horsepower];
X = [linear_X Weight .* Horsepower];

% Perform the linear regression, using the 'regress' function.
% The function returns lots of information about the fit, but in
% this example, we only care about the coefficients: the offset
% and the slopes for the weight and horsepower.
[linear_coeffs, ~, ~, ~, linear_stats] = regress(MPG, linear_X);
[nonlinear_coeffs, ~, ~, ~, nonlinear_stats] = regress(MPG, X);

%% Show the original data
plot3(Weight, Horsepower, MPG, ...
	'LineStyle', 'none', ...
	'Marker', 'o', ...
	'Color', 'k');
xlabel('Weight', 'FontSize', 18);
ylabel('Horsepower', 'FontSize', 18);
zlabel('MPG', 'FontSize', 18);
hold on;

%% Plot the fitted regression surfaces.
% First we plot the linear, then the nonlinear surface.
weight_vals = linspace(min(Weight), max(Weight), 100);
horse_vals = linspace(min(Horsepower), max(Horsepower), 100);
[xvals, yvals] = meshgrid(weight_vals, horse_vals);
mesh(xvals, yvals, ...
	linear_coeffs(1) + ...
	linear_coeffs(2) .* xvals + ...
	linear_coeffs(3) .* yvals, ...
	'FaceAlpha', 0.25, ...
	'EdgeAlpha', 0.25);
mesh(xvals, yvals, ...
	nonlinear_coeffs(1) + ...
	nonlinear_coeffs(2) .* xvals + ...
	nonlinear_coeffs(3) .* yvals + ...
	nonlinear_coeffs(4) .* xvals .* yvals, ...
	'FaceAlpha', 0.5, ...
	'EdgeAlpha', 0.5, ...
	'FaceColor', 'flat');

% Pretty up the plot
grid on;
set(gca, 'TickDir', 'out', 'FontSize', 18);
title(sprintf(['Multiple nonlinear regression\n' ...
	'Linear r^{2}: %0.2g\n' ...
	'Nonlinear r^{2}: %0.2g'], linear_stats(1), nonlinear_stats(1)), ...
	'FontSize', 24);
view(46, 24);
