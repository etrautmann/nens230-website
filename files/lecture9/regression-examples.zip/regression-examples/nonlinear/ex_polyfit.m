function [] = ex_polyfit()
% FUNCTION [] = ex_polyfit()
%
% NENS 230 lecture 9
% Example of polynomial fitting.
%
% (C) 2014 Benjamin Naecker bnaecker@stanford.edu

%% Generate data
x = linspace(-5, 5, 100)';
true_params = [10; -15; 0; 1];
sd = 3;
X = [ones(size(x)), x, x.^2, x.^3];
y = X * true_params + 5 * 3 * randn(size(x));

%% Use the polyfit function to estimate the coefficients of a polynomial, and
% compute the predicted y-values
degree = 3;
p = polyfit(x, y, degree);
yhat = X * fliplr(p)';

%% Show the fit
plot(x, y, ...
	'LineStyle', 'none', ...
	'Marker', 'o', ...
	'Color', 'k');
hold on;
plot(x, yhat, ...
	'LineStyle', '-', ...
	'Marker', 'none', ...
	'Color', [0 0.2 0.7], ...
	'LineWidth', 5);

%% NOTE! You can do exactly the same thing above with plain old mldivide.
% The only difference here is that I have to explicitly construct the design
% matrix 'X' myself. It's easy enough since I already had it here for generating
% the data. But it's probably easier to just use 'polyfit'.
p2 = X \ y;
plot(x, X * fliplr(p)', ...
	'LineStyle', '--', ...
	'Marker', 'none', ...
	'Color', [0.7 0 0.2], ...
	'LineWidth', 2);
legend({'Data', 'Polyfit', 'OLS'});
hold off;
box off; grid on;
set(gca, 'TickDir', 'out', 'FontSize', 18);
title(sprintf('Fitting a degree-%d polynomial', degree), ...
	'FontSize', 24);
