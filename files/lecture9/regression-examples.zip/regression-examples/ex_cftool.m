% ex_cftool.m
% 
% NENS 230 lecture 9
% Script for illustrating the interactive curve-fitting tool.
%
% (C) 2014 Benjamin Naecker bnaecker@stanford.edu

%% Intro
% The curve-fitting tool, or 'cftool', is a very powerful graphical interface for 
% fitting curves and surfaces to data. It allows you to load data, try many different
% types of fits easily, and save the results quickly.

%% Example 1: Linear regression
% This example generates data and walks through the steps for using the cftool to do
% simple linear regression.
n = 50;
linear_x = (1:n)';
slope = 2;
offset = -10;
sd = 10;
linear_y = offset + slope .* linear_x + sd .* randn(n, 1);

% 1 - Type 'cftool' in the Matlab command window
%
% 2 - At the top left, we have the data selection area. This is where we choose
% 	dependent and independent variables for our fit. From the 'X data' and 'Y 
% 	data' drop-down menus, select, 'linear_x' and 'linear_y', respectively. 
%
%  	The 'Auto fit' check box should be checked by default, which means that as soon as
%	you select data, Matlab will fit the requested curve. This should have fit a 1-degree
%	polynomial to the data, which is linear regression. The data and the fit itself should
%	appear in the center.
% 
% 3 - On the left, we see the results of the fit. This includes the description of the model,
%	the coefficients fit, and a quantification of the goodnes-of-fit, such as the r-square.
%	Because our model is simple, and we don't have much noise, the r-square shouldbe quite 
% 	good, well over 0.9.
%
% 4 - At the top center, we have menus for selecting the type of fit to make. The first
%	drop-down menu indicates the general class, such as 'Polynomial', or 'Sum of sine'.
%	The menus below this will change, depending on the type of fit we select.
%
% 5 - Before continuing on to our next example, note that you can always ask Matlab to 
%	save the results of fitting, either to a file or the workspace, by right-clicking on
%	the fit in the 'Table of Fits' at the bottom, and selecting 'Save ...'.

%% Fitting a simple exponential
simple_exp_x = linspace(0.01, 5, n)';
simple_exp_prs = [10, -0.1, -5];
sd = 1;
simple_exp_y = simple_exp_prs(3) + simple_exp_prs(1) .* ...
	exp(simple_exp_prs(2) .* simple_exp_x) + sd .* randn(n, 1);

% All that should be required here is to select the 'Exponential' option from the fit
% type menu and chnage the X and Y data from their drop-down menus. Voila.

%% Fitting custom exponential
exp_x = linspace(0.01, 5, n)';
prs = [10, -0.1, -5];
sd = 1;
exp_y = prs(3) + prs(1) .* exp(prs(2) .* x) + sd .* randn(n, 1);

% 1 - Now select 'exp_x' and 'exp_y' from the data menus, select 'Exponential' from the 
% 	drop-down fit type menu. The plot should update to show the new data and fit.
%
% 2 - You should see that the fit is actually pretty terrible. This nonlinear regression
%	is actually a pretty difficult problem to get correct, because there's just too many
% 	possible parameters to try them all. But let's say we know something Matlab doesn't,
%	that there is a negative offset to our data. For example, this might be the log of
% 	a concentration of some chemical, so a value of -5 really means 0.00001 M. We can 
% 	tell Matlab that it should assume there is some offset to the data.
%
% 3 - From the drop-down fit-type menu, select 'Custom Equation'. In the bigger, lower
% 	box, we can write in our own custom equation. The upper box should say 'y = f(x)', 
% 	which tells Matlab that there is a single input, 'x', and a single output 'y'. Anything
%	else in the definition of the function is something Matlab can play with to get a 
%	better fit to the data.
%
% 4 - In that lower box, write: 'a*exp(-b*x)+c'. This is an expression that tells Matlab
% 	the following: We want y to be an exponential function of x. There should be three
%	parameters that can be changed, the steepness of the exponential decay (b), the height
%	of the overall exponential (a) and a linear offset applied to the whole function (c).
%
% 5 - If the 'Auto Fit' box is checked, Matlab should pretty much just go ahead and fit.

%% Saving and using fit objects
% All the information about a fit is saved in a special datatype, called a fit object.
% This includes things like, the definition of the function, the parameter values,
% the r-square and RMSE, etc. These objects can be saved and reloaded, passed around
% to other functions, and used to plot new data.

% 1 - Save the custom exponential fit we made above to the workspace. At the bottom
%	in the 'Table of Fits' section, right-click on the fit and select 'Save untitled
%	fit 1 to workspace'. A dialog will pop up asking you to name the varialbes to
% 	be saved, but just use the defaults.
%
% 2 - Back in the workspace, you see that several new variables have appeared. 
%	'fittedmodel' contains the function definition and parameters obtained by the fit.
%	'goodness' contains information about how accurate the fit is, such as r-square.
%	'output' contains detailed information about how the fit was achieved, which will
%	probably not be very useful in most cases.
%
% 3 - We can plot the fit that we've created, without specifying axes or the points
%	at which to plot. Just calling 'plot(fittedmodel)' will plot the model over the
%	range of values where it was constructed. 
% 
% 4 - But we can also use the fit object as if it actually *is* the function itself. 
%	Type this: 'fittedmodel(1)'. This should spit back something around -1, which is
%	the fit itself evaluated at the point -1. We can also use this to easily plot
% 	the fit over some new range of data. For example:
%		new_x = linspace(0.5, 4, 10);
%		plot(new_x, fittedmodel(new_x));
%	will plot the new model evaluated at that new x-range.

%% More
% There is a whole more that we can do with the curve fitting tool. Read all about it
% in the Matlab documentation. Some of the coolest features are:
%	1 - Weighted linear regression
%	2 - Easy regularization
%	3 - Fitting of surfaces and 2D probability distributiions
