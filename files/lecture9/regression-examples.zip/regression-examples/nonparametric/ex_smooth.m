function [] = ex_smooth(method)
% FUNCTION [] = ex_smooth(method)
%
% NENS 230 lecture 9
% Example of smoothing data
%
% Smoothing data is a huge topic, with whole books devoted to it. But the core
% of the idea is very simple: remove some of the noise in our data to get a
% more clear picture of the underlying trends. This can be done in many ways,
% but here we look at Matlab's 'smooth' function, which computes several types of
% moving averages of the given data.

%% Parse input
if nargin == 0
	method = 'moving';
end

%% Generate noisy data
n = 50; 
span = 5;
sd = 0.25;
x = linspace(0, 4 * pi, n)';
y = sin(x) + sd .* randn(n, 1);

%% Smooth the data 
smooth_data = smooth(x, y, span, method);

%% Plot
plot(x, y, ...
	'LineStyle', '-', ...
	'Marker', 'none', ...
	'Color', 'k', ...
	'LineWidth', 2);
hold on;
plot(x, smooth_data, ...
	'LineStyle', '--', ...
	'Marker', 'none', ...
	'Color', 'r', ...
	'LineWidth', 3);
legend({'Data', ...
	sprintf('Smoothed with "%s" filter', method)});
box off; grid on;
set(gca, 'TickDir', 'out', 'FontSize', 18);
title('Smoothing data', 'FontSize', 24);
