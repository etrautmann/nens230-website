function [] = ex_interp1(n, method)
% FUNCTION [] = ex_interp1(n, method)
%
% NENS 230 lecture 9
% Example use of 'interp1' 1D interpolation function. Interpolation is the
% process of using known, neighboring points to determine the value of an
% unknown point. This involves essentially making a smooth curve between the
% known points, and using that curve to generate the unknown values. These
% intervening curves can be of many different shapes. Two of most common are
% linear interpolation, which draws a straight line between neighbors, and
% "nearest-neighbor", which just assumes unmeasured data is equal to the nearest
% measured neighbor.
%
% Input:
% 	n		- Number of points in original signal
% 	method	- Interpolation method. Can be any of those accepted by interp1.
%
% (C) 2014 Benjamin Naecker bnaecker@stanford.edu

%% Parse input
if nargin == 0
	n = 30;
	method = 'linear';
elseif nargin == 1
	method = 'linear';
end

%% Generate data
x = linspace(0, 4 * pi, n);
y = sin(x);

%% Interpolate
x_interp = linspace(0, 4 * pi, 2 * n);
y_interp = interp1(x, y, x_interp, method);

%% Show the interpolation
plot(x, y, ...
	'LineStyle', 'none', ...
	'Marker', 'o', ...
	'LineWidth', 1, ...
	'MarkerSize', 10, ...
	'Color', 'k'); 
hold on;
plot(x_interp, y_interp, ...
	'LineStyle', '--', ...
	'Marker', 'x', ...
	'LineWidth', 1, ...
	'MarkerSize', 6, ...
	'Color', 'r'); 
legend({'Data', sprintf('%s interpolation', method)});
hold off;
set(gca, 'TickDir', 'out', 'FontSize', 18);
title('Interpolating between datapoints', 'FontSize', 24);
box off; grid on;
