function [lin_coeffs, rob_coeffs] = ex_robustfit(slope, offset, sd, outlier_sd)
% FUNCTION [lin_coeffs, rob_coeffs] = ex_robustfit(slope, offset, sd, outlier_sd)
%
% NENS 230 lecture 9
% Example of robust linear regression vs standard least-squares fitting.
%
% Input:
% 	slope			- True slope for linear relationship.
%	offset			- True offset for linear relationship.
%	sd				- Standard deviation of noise for majority of points.
%	outlier_sd		- Standard deviation of outlier points.
%
% Output:
%	lin_coeffs	- Ordinary least-squares regression coefficients.
%	rob_coeffs	- Robust least-squares regression coefficients.
%
% (C) 2014 Benjamin Naecker bnaecker@stanford.edu

%% Parse inputs
if nargin == 0
	slope = 2.5;
	offset = 10;
	sd = 10;
	outlier_sd = 100;
elseif nargin == 1
	offset = 10;
	sd = 10;
	outlier_sd = 50;
elseif nargin == 2
	sd = 10;
	outlier_sd = 100;
elseif nargin == 3
	outlier_sd = 100;
end

%% Generate starting data.
n = 100;
x = linspace(0, 10, n)';
observations = offset + slope .* x + sd .* randn(n, 1);

%% Manipulate the outliers.
% Here we add a huge random positive amount to the outliers..
noutliers = 5;
outlier_start = 85;
outliers = randsample(outlier_start : n, noutliers);
outlier_noise = abs(outlier_sd .* randn(noutliers, 1));
observations(outliers) = offset + slope .* x(outliers) + outlier_noise;

%% Use standard least-squares regression to estimate the coefficients
X = [ones(n, 1) x];
lin_coeffs = X \ observations;

%% Use robust least-squares to estimate the coefficients. 
% Note that 'robustfit' does not require us to add a column of 1's manually.
rob_coeffs = robustfit(x, observations);

%% Plot the difference between the two linear fits
plot(x, observations, ...
	'LineStyle', 'none', ...
	'Marker', 'o', ...
	'LineWidth', 1.5, ...
	'MarkerSize', 10, ...
	'Color', 'k');
hold on;
plot(x(outliers), observations(outliers), ...
	'LineStyle', 'none', ...
	'Marker', 'o', ...
	'LineWidth', 1.5, ...
	'MarkerSize', 10, ...
	'Color', 'r');
plot(x, X * lin_coeffs, ...
	'LineStyle', '-', ...
	'LineWidth', 2, ...
	'Color', [0 0.2 0.7]);
plot(x, X * rob_coeffs, ...
	'LineStyle', '-', ...
	'LineWidth', 2, ...
	'Color', [0 0.7 0.2]);
legend({...
	'Observations', ...
	'Outliers', ...
	'Least-squares', ...
	'Robust least-squares'}, ...
	'Location', 'NorthWest');
box off, grid on;
set(gca, 'TickDir', 'out', 'FontSize', 20);
title('Ordinary vs robust regression', 'FontSize', 24);
hold off;
