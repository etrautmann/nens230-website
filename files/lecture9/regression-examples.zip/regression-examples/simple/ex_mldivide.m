function estimated_parameters = ex_mldivide(slope, offset, sd)
% FUNCTION estimated_parameters = ex_mldivide(slope offset, sd)
%
% NENS 230 lecture 9
% Example of 'mldivide' or '\' (backslash) operator for linear regression.
%
% Input:
%	slope	- True slope for noisy linear regression.
% 	offset 	- True offset for noisy linear regression.
%	sd		- Standard deviation for Gaussian noise.
%
% Output:
%	estimated_parameters - The least-squares estimates for the parameters
% 		of the linear regression model.
%
% (C) 2014 Benjamin Naecker bnaecker@stanford.edu

%% Parse inputs
if nargin == 0
	slope = 2.5;
	offset = 10;
	sd = 10;
elseif nargin == 1
	offset = 10;
	sd = 10;
elseif nargin == 2
	sd = 10;
end

%% Generate data. 
% The data consists of noisy observations of a linear relationship between
% a single independent variable and a single dependent variable.
n = 100;
x = (1:n)';
observations = offset + slope .* x + sd .* randn(n, 1);

%% Compute least-squares solution
% The '\' (backslash) operator is the easiest and quickest way to solve
% a simple linear regression problem. It uses a few tricks from linear 
% algebra (the psuedo-inverse, if you're curious) to compute the least-
% squares estimates for the two parameters in the problem, 'slope' and
% 'offset'.

% The column of ones here is a constant term in the system of equations,
% that allows us to compute the offset. Another way to think of this is 
% that we want one parameter that is constant (always multiplied by 1),
% and one that is always multiplied by x (the slope).
X = [ones(n, 1) x];
estimated_parameters = X \ observations;

% The above line is equivalent to all of the following, but is usually more
% robust and definitely more simple, for technical reasons.
% prs = mldivide(X, observations);
% prs = inv(X) * observations;
% prs = pinv(X) * observations;
% prs = regress(observations, X); % But see ex_regress.m

%% Plot data and least-squares solution.
plot(x, observations, ...
	'Marker', 'o', ...
	'LineStyle', 'none', ...
	'MarkerSize', 10, ...
	'Color', [0 0.2 0.7], ...
	'LineWidth', 2);
hold on;
plot(x, X * estimated_parameters, ...
	'LineStyle', '-', ...
	'LineWidth', 3, ...
	'Color', 'k');
legend({'Observations', 'Least-squares fit'}, ...
	'Location', 'NorthWest');
box off, grid on;
set(gca, 'TickDir', 'out', 'FontSize', 18);
title('Regression using the "\" operator', 'FontSize', 24);
hold off;
