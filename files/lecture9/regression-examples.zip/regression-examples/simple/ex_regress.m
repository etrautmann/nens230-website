function [coeffs, confidence_intervals, residuals, statistics] = ...
	ex_regress(slope, offset, sd)
% FUNCTION [coeffs, confidence_intervals, residuals, statistics] = ... 
%	ex_regress(slope, offset, sd)
%
% NENS 230 lecture 9
% Example using 'regress' function for simple linear regression
%
% Input:
%	slope 	- True slope for linear model.
%	offset	- True offset for linear model.
%	sd		- Standard deviation of Gaussian noise.
%
% Output:
%	coeffs					- The regression coefficients, offset and slope.
%	confidence_intervals	- 95% confidence intervals for the coefficients.
%	residuals				- Errors between true and predicted values.
%	statistics				- F statistic and p-value for the full model, as
%								well as an estimate of error variance.
%
% (C) 2014 Benjamin Naecker bnaecker@stanford.edu

%% Parse inputs
if nargin == 0
	slope = 2.5;
	offset = 10;
	sd = 10;
elseif nargin == 1
	offset = 10;
	sd = 10;
elseif nargin == 2
	sd = 10;
end

%% Generate data. 
% The data consists of noisy observations of a linear relationship between
% a single independent variable and a single dependent variable.
n = 100;
x = (1:n)';
observations = offset + slope .* x + sd .* randn(n, 1);

%% Compute regression coefficients.
% The 'regress' function is a bit of overkill for simple linear regression,
% but it is useful to see it in a very basic example. It gives us a whole bunch
% of information about the goodness of fit, including confidence intervals,
% residuals, and goodness-of-fit statistics.
X = [ones(n, 1) x];
[coeffs, confidence_intervals, residuals, ~, statistics] = ...
	regress(observations, X);

%% Plot the observations and fit, including confidence bounds
plot(x, observations, ...
	'LineStyle', 'none', ...
	'Marker', 'o', ...
	'LineWidth', 2, ...
	'MarkerSize', 10, ...
	'Color', [0 0.2 0.7]);
hold on;
plot(x, X * coeffs, ...
	'LineStyle', '-', ...
	'Color', 'k', ...
	'LineWidth', 3);
plot(x, X * (coeffs - confidence_intervals(:, 1)), ...
	'LineStyle', '--', ...
	'Color', [0.7 0 0.2], ...
	'LineWidth', 1);
plot(x, X * (coeffs + confidence_intervals(:, 2)), ...
	'LineStyle', '--', ...
	'Color', [0.7, 0, 0.2], ...
	'LineWidth', 1);
legend({'Observations', ...
	'Least-squares fit', ...
	'95% confidence'}, ...
	'Location', 'NorthWest');
hold off;
box off, grid on;
set(gca, 'TickDir', 'out', 'FontSize', 18);
title('Linear regression with the "regress" function', ...
	'FontSize', 24);
