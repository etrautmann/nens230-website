%% NENS 230: Problem Set #6 Solution
%  Niru Maheswaranathan (nirum@stanford.edu)
%  Fri Nov 23 03:00:44 2012

%% Problem 1) Image Sharpening

% load image
img = imread('retina.jpg');     % load retina image
img = double(rgb2gray(img));    % flatten color channels, convert to double

% threshold image
threshold = 100;                % choose the threshold
img_thresh = img > threshold;   % threshold the image

% smooth + threshold
F = fspecial('gaussian',9,2);   % define the gaussian (smoothing) filter
img_filt = imfilter(img, F);    % filter the image
img_st = img_filt > threshold;  % threshold the smoothed image

% plots
figure(1); colormap gray;
subplot(131); imagesc(img); title('Original Image'); axis image;
subplot(132); imagesc(img_thresh); title('Thresholded Image'); axis image;
subplot(133); imagesc(img_st); title('Smoothing + Threshold'); axis image;

%% Problem 2) Fourier Transform
load sim_eeg.mat;

% trace labels
names = {'Background Activity', 'Sporadic Spikes', 'Rhythmic Activity', 'Slow quasi-sinusoidal activity'};

% for each trace
figure(2);
for j = 1:4

    % compute FFT
    [freq, F] = computeft(t,v(:,j));
    F = F./max(F);                          % normalize

    % plot original signal
    subplot(4,2,2*j-1); plot(t,v(:,j)); xlabel('Time (s)'); ylabel('y(t)');
    axis tight; grid on;

    % plot Fourier Transform
    subplot(4,2,2*j); plot(freq,F); xlabel('Frequency (Hz)'); ylabel('|F(\omega)|');
    axis([0 50 0 1]); grid on;

end

%% Problem 3) ECG
load ecg;

% (a) plot the waveforms
figure(3);
subplot(311); plot(norm.time, norm.V); title('Normal');
xlabel('Time (min)'); ylabel('Voltage (V)');
subplot(312); plot(atro.time, atro.V); title('Atropine');
xlabel('Time (min)'); ylabel('Voltage (V)');
subplot(313); plot(epi.time, epi.V); title('Epinephrine');
xlabel('Time (min)'); ylabel('Voltage (V)');

% (b) peak detection
[tmax1, tmin1, vmax1 vmin1] = peakanalysis(norm.time, norm.V, 0.04);
subplot(311); hold on; plot(tmax1, vmax1, 'mo', tmin1, vmin1, 'co'); hold off;

[tmax2, tmin2, vmax2, vmin2] = peakanalysis(atro.time, atro.V, 0.021);
subplot(312); hold on; plot(tmax2, vmax2, 'mo', tmin2, vmin2, 'co'); hold off;

[tmax3, tmin3, vmax3, vmin3] = peakanalysis(epi.time, epi.V, 0.02);
subplot(313); hold on; plot(tmax3, vmax3, 'mo', tmin3, vmin3, 'co'); hold off;

% (c) classification
figure(4);
plot(vmin1, vmax1(1:16), 'ro', vmin2, vmax2(1:17), 'g*', vmin3, vmin3(1:17), 'bs');
xlabel('Minima'); ylabel('Maxima');
legend('Normal','Atropine','Epinephrine');
