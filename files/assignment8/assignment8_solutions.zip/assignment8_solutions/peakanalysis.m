% Peak Analysis function
% Niru Maheswaranathan
% Sun Oct 28 03:00:47 2012

function [tmax, tmin, vmax, vmin] = peakanalysis(time, voltage, threshold)

    [maxtab, mintab] = peakdet(voltage, threshold);

    tmax = time(maxtab(:,1));                           % time of maxima
    vmax = maxtab(:,2);                                 % voltage at maxima

    tmin = time(mintab(:,1));                           % time of minima
    vmin = mintab(:,2);                                 % voltage at minima
