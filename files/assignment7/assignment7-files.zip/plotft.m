% Computes Fourier Transform of given signal
% Niru Maheswaranathan
% Sat Jun 23 19:49:27 2012
% [freq,F] = plotft(t,y)

function [f,F] = computeft(t,y)

    % get the sampling frequency
    dt = mean(diff(t));
    fs = 1/dt;

    % compute the frequency vector
    f = linspace(0,fs,length(y));

    % compute the FFT
    F = abs(fft(y));
