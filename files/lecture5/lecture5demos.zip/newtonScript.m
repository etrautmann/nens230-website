% NENS 230 2015 Example
% This script computes sqrt of 3, 10, and 100 using Newton's Method.
root4 = 1;
for i = 1:100
    root4 = (root4+4./root4)/2;
end
fprintf('Square root of 4 is %g (true answer is %g)\n', root4, sqrt(4) )

root10 = 1;
for i = 1:100
    root10 = (root10+10./root10)/2;
end
fprintf('Square root of 10 is %g (true answer is %g)\n', root10, sqrt(10) )


root100 = 1;
for i = 1:100
    root100 = (root100+10./root100)/2;
end
fprintf('Square root of 100 is %g (true answer is %g)\n', root100, sqrt(100) )










%% Better way to do this is to call a funciton, sqrtNewton, that implements this computation.
rootThese = [4, 10, 100];
rootsList = nan( size( rootThese ) );
for i = 1 : numel( rootThese )
    rootsList(i) = sqrtNewton( rootThese(i) );
    fprintf('Square root of %g is %g (true answer is %g)\n', ...
        rootThese(i), rootsList(i), sqrt( rootThese(i) ) );    
end
