function out = sqrtNewton(in)
% sqrtNewton Finds the square root of a number
% using Newton's Method
% out = sqrtNewton(in)
% 
% INPUTS
% in - the number to take the square root of
% 
% OUTPUTS
% out - the square root of in
 
out = 1;
for i = 1:100
    out = (out+in./out)/2;
end
 
end