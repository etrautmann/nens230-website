% timingExample.m
% NENS 230 Autumn 2015
%
% Demonstrates timing how long pieces of code take using tic and toc


%% tic and toc lets you see how long a function takes

% Let's see how long a few operations takes:
A = rand(50); %50x50 random matrix

tic
B = inv(A);   %calculate matrix inverse
traceB = trace( B );
toc

%% For very fast operations, estmate is noisy. 
% So run it many times and report mean.
% Also note that the first execution is much slower 
% (MATLAB optimizes for next time)
N = 10000;
tic
for i = 1 : N
    clear('B')
    B = inv(A);   %calculate matrix inverse
    traceB = trace( B );
end
fprintf('Mean execution time is %fs\n', toc / N )


