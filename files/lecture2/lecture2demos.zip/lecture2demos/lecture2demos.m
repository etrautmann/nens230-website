%% Lecture 2: DATA DATA DATA
% Examples of data manipulation and import with MATLAB.
% Sergey Stavisky, September 29th 2015

%% Exploring MRI data
% Let's load the built-in MRI data set, and image a brain slice
load mri;                                   % load built-in MRI data set
img = squeeze( D );                           % singleton dimensions

figure(1);
imagesc( img(:,:,14) );                       % image the 14th slice
colormap( map );
title( 'Axial Slice' );

figure(2);
% The above image is an axial (horizontal) slice of the data cube. Now
% let's extract a different slice.
prof = squeeze( img(:,64,:) );
image(prof); colormap( map );
% transpose it
prof = squeeze( img(:,64,:) )';
image(prof)
% flip it upside down
prof = flipud(squeeze(img(:,64,:))');       % get mid-sagittal section
image(prof);                              % image the extracted slice
title('Mid-Sagittal Slice');

%% Looking at a neuron
% (demonstrates image read, loading, comparison, nnz, find)
neurons = imread( 'neurons.tif' );
figure(3); image(neurons)

% Look at just the red channel
imagesc( neurons(:,:,1) ) % note imagesc scales image to full color range

% Look at just the blue channel
imagesc( neurons(:,:,3) )

% Apply a threshold - could be start of 
% cell detection algorithm
colorbar; % looks like ~50 should be good threshold
hasNucleus = neurons(:,:,3) > 50;
size( hasNucleus )
% plot it
imagesc( hasNucleus )

% what fraction of image has nucleus?
fracNucleus = nnz( hasNucleus ) / numel( hasNucleus );
fprintf('%.1f%% of image is nucleus\n', 100*fracNucleus )

% Highlight areas with bright in both red and blue channel
imagesc( neurons(:,:,1) ); colorbar;
hasStain = neurons(:,:,1) > 250;
hasBoth = hasNucleus & hasStain; % elementwise &
figure;
imagesc( hasBoth )
% Find its center
[rows, cols] = find( hasBoth );
meanx = mean( cols ); % note cols are x coordiantes
meany = mean( rows );
% plot original image and mark this red+blue overlap
image( neurons ); 
hold on;
plot( meanx, meany, 'xw', 'MarkerSize', 20)


%% Stockprices
% demonstrates csv read, find()
stocks = csvread('stockprices.csv', 1 );
figure; 
plot(stocks(:,1),stocks(:,2), 'r') % BSX
hold on
plot(stocks(:,1),stocks(:,3), 'b') % MDT
xlabel('Week')
ylabel('Price ($)')

% At what week did BSX first go above 40$?
myIndex = find(stocks(:,2)>40,1, 'first')
fprintf('BSX went above 40 at week %i\n', stocks(myIndex,1) )
fprintf('It cost %.2f dollars then\n', stocks(myIndex,2) )

% Fancier stuff - automatically get names of the stocks
fid = fopen('stockprices.csv'); % open file for reading
in = textscan(fid,'%s %s %s', 1, 'Delimiter', ',');
fclose(fid); % close file
legend({in{2}{1},in{3}{1}}); % unpack it