% SpikeTriggeredAverageStimulus.m
%
% Computes the spike-triggered average (STA) stimulus preceding an action 
% potential from a recorded neuron. You provide a vector of spike
% times and a recording of the stimulus intensity. The user can specify the taus
% that will be sampled. Returns a vector <STA> which is the average stimulus intensity
% at time <tau> preceding a spike of this cell.
%   For example, if the stimulus recording gave the brightness value of a full
% field illumination of a retina, and the spike times are the recorded spikes
% of a retinal ganglion cell (RGC) when exposed to this stimulus, and <tau>
% is [1 10 100] then  STA would be a length 3 vector where the elements represent 
% the average stimulus brightness 1, 10, and 100 ms before this RGC spikes.
% In effect, the STA is an estimate of the response function of the RGC,
% i.e. what kind of stimulus pattern most likely evokes a spike from the neuron.
%
%
% NOTE: spikeTimes and stim.t should be in the same units (ms)
% and coordinated; thus, if stim.t times go from 0 to 1e5 ms (100 seconds)
% then spikeTimes should also be in ms and a spikeTime of 0 would correspond 
% to a spike at the very start of the stimulus. 
%
% Created by Sergey Stavisky on 8 November 2011
% Last modified by Sergey Stavisky on 20 November 2011



function [STA C tau] = SpikeTriggeredAverageStimulus( filea, fileb, tau, arg4 )
% Load and confirm the spike times
load( filea )
if ~exist( 'spikeTimes', 'var' )
    error('waaah!')
end
% Load and confirm the stimulus
load( fileb )
if ~exist( 'stimt', 'var' ) || ~exist('intensity', 'var')
    error('WAAAAH!')
end

% INSTRUCTOR COMMENT:
% You do NOT need to improve the plotStimAndSpikes function.
% It's just to show you what the raw data looks like.
plotStimAndSpikes( spikeTimes, stimt, intensity );
% END OF INSTRUCTOR COMMENT

% take care of the beginning of the data
if arg4 > max( tau )
spikeTimes( spikeTimes < arg4 ) = [];
end
if max( tau ) > arg4
spikeTimes( spikeTimes < max( tau ) ) = [];
end
C = 0; % keeps track of how many usable spikes we've seen.
for i = 1 : length( spikeTimes )
st = spikeTimes(i); % my spike time
% Make sure we actually have stimulus preceding this spike all the way to
% tau(1) beforhand
if max( stimt ) >= st - tau(1)
% Ok great this spike can be analyzed
C = C + 1
% tau loop
for j = 1 : length( tau )
    T = find( stimt == st - tau); % want to look tau(j) back in time from spike time, so find when
                                  % stimt equals time st - tau (e.g., if st is 3008 and tau is 11 ms,
                                  % find when stimt equals 2997 ms). 
    STA(C, j) = intensity(T);
end

% Plot after 10 spikes
if C == 10
STAmean = mean( STA, 1 );
figh = figure('Name', 'STA after 10 spikes');
axh = axes( 'Parent', figh );
linesh = plot( tau, STAmean , 'Parent', axh );
axh.XDir = 'reverse';
linesh.Color = 'k';
linesh.LineWidth = 3;
axh.FontSize = 12;
line( axh.XLim, [0 0], 'LineStyle', ':', 'Color', [.5 .5 .5], 'LineWidth', 1 );
xlabel('\tau (ms before spike)', 'FontSize', 16)
ylabel('Average Stimulus Intensity (AU)', 'FontSize', 16)
titlestr{1} = 'Spike-Triggered Average Stimulus';
titlestr{2} = '(averaged over 10 spikes)';
title( titlestr, 'FontSize', 18, 'FontWeight', 'bold' );    
drawnow; % will display it before program finishes. This is an advanced feature, ton't worry about it
         % I've put it here so you don't die of boredom when the code is running.
end
% Plot after 100 spikes
if C == 500
STAmean = mean( STA, 1 );
figh = figure('Name', 'STA after 500 spikes');
axh = axes( 'Parent', figh );
linesh = plot( tau, STAmean , 'Parent', axh );
axh.XDir = 'reverse';
linesh.Color = 'k';
linesh.LineWidth = 3;
axh.FontSize = 12;
line( axh.XLim, [0 0], 'LineStyle', ':', 'Color', [.5 .5 .5], 'LineWidth', 1 );
xlabel('\tau (ms before spike)', 'FontSize', 16)
ylabel('Average Stimulus Intensity (AU)', 'FontSize', 16)
titlestr{1} = 'Spike-Triggered Average Stimulus';
titlestr{2} = 'averaged over 500 spikes)';
title( titlestr, 'FontSize', 18, 'FontWeight', 'bold' );    
drawnow; % will display it before program finishes. This is an advanced feature, ton't worry about it
end

end
end
STAmean = mean( STA, 1 );







% last figure
figh = figure('Name', 'STA after all spikes');
axh = axes( 'Parent', figh );
linesh = plot( tau, STAmean , 'Parent', axh );
axh.XDir = 'reverse';
linesh.Color = 'k';
linesh.LineWidth = 3;
axh.FontSize = 12;
line( axh.XLim, [0 0], 'LineStyle', ':', 'Color', [.5 .5 .5], 'LineWidth', 1 );
xlabel('\tau (ms before spike)', 'FontSize', 16)
ylabel('Average Stimulus Intensity (AU)', 'FontSize', 16)
titlestr{1} = 'Spike-Triggered Average Stimulus';
titlestr{2} = sprintf('(averaged over %i spikes)', C );
title( titlestr, 'FontSize', 18, 'FontWeight', 'bold' );
end