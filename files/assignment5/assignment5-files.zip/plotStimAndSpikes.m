function figh = plotStimAndSpikes( spikeTimes, stimt, intensity )
% NENS 230 Autumn 2015
% Called by SpikeTriggeredAverageStimulus.m to create a figure showing the 
% visual stimulus projected onto the retina, with marks to denote when the spikes
% happened. 
% You don't need to improve this function, it's just to help you see the raw data!
%
% USAGE:
%       figh = plotStimAndSpikes( spikeTimes, stim )
%
% INPUTS:
%       spikeTimes   Vector of time (in ms) of each spike.
%     
%       stimt        time of stimulus data
%       intensity    intensity of the stimulus at correspondiung time in <stimt>
% OUTPUTS:
%       figh         Figure handle of resulting figure.
%       
% Created by Sergey Stavisky on 12 October 2015
% Last modified by Sergey Stavisky on 12 October 2015
    % Figure out the axes; do this based on 
    minT = min( [spikeTimes ; stimt] );
    maxT = max( [spikeTimes ; stimt] );
    % set y limits based on maximum value of stimulus intensity
    yMax = max( intensity );
    yMin = min( intensity );
    yAbsMax = ceil( max( abs( [yMax yMin] ) ) );
    
    % Generate figure and axes. Note that I don't plot the whole time series
    % or it is too compressed. It still benefits from zooming in with the plot
    % tools.
    figh = figure( 'Name', 'Unprocessed Stimulus and Spike Times', ...
        'Position', [50 50 1400 450]);
    axh = axes( 'Parent', figh, 'FontSize', 12, 'XLim', [minT 12e4], ...
        'YLim', [-yAbsMax yAbsMax]  ); % dont show all extra spikes
    hold on
    
    % Plot stimulus intensity
    stimh = plot( stimt, intensity, 'Color', 'r', 'LineWidth', .5, 'Parent', axh );
    
    % Plot spikes with vertical lines
    linesh = line( [spikeTimes spikeTimes], [yAbsMax-1 yAbsMax], 'Color', 'k', 'LineWidth', 1 );

    % Labels
    xlabel('Time (ms)', 'FontSize', 16)
    ylabel('Stimulus (AU)', 'FontSize', 16)
    titlestr = 'Stimulus and Evoked Spikes';
    title( titlestr, 'FontSize', 18, 'FontWeight', 'bold' );    
end