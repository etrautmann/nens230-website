%% Coffee shop analysis ... with bugs!
%  NENS 230
%  Created On: 9/24/2012
%  Edited On: 10/28/2013

%% Load coffee data (note: this is simulated, or fake, data)
%   t:     time of day (in hours, military time)
%   lksc:  number of visitors to LKSC coffee shop at a given hour
%          during each day of the year
%   peets: number of visits to Peet's coffee shop at a given hour
%          during each day of the year
load('coffeeData.mat');

%% (A) Plot daily averages + std. error

% Take the mean over rows to compute yearly average
peetsMean = mean(peets,1);
lkscMean  = mean(lksc,1);

% compute standard error of the mean, by taking the
% standard deviation over the rows and dividing by the square root
% of the number of days used to compute the std. dev.
peetsSigma = std(peets,0,1)/sqrt(size(peets,1));
lkscSigma  = std(peets,0,1)/sqrt(size(peets,1));

% plot the avg. number of visitors during the course of a day
figure(1); hold on;
h1 = errorbar(t,peetsMean,peetsSigma, 'r.-');
h2 = errorbar(t,lkscMean ,lkscSigma , 'b.-');
xlabel('Time of Day (hours)');
ylabel('Mean number of visitors');
legend('Peets', 'LKSC');

%% (B) Plot yearly trend

% Take the average over all times for each day
peetsYearly = mean(peets,1);
lkscYearly  = mean(lksc,1);

% group into (rough) monthly averages
binSize = ceil(size(peets,2)/12);

% loop over different months
for i = 1:12

    % compute the bounds for this month
    lb = binSize*(i-1) + 1;   % lower bound
    ub = binSize*i;           % upper bound

    % average visits in this month by slicing out the data within the bounds
    peetsMonthly(i) = mean(peetsYearly(lb:ub));
    lkscMonthly(i)  = mean( lkscYearly(lb:ub));

end

% plot the avg. number of visitors during the course of a year
figure(2);
plot(1:12, peetsMonthly, 'ro-', ...
     1:12,  lkscMonthly, 'bo-');
legend('Peets', 'LKSC');
xlabel('Month');
ylabel('Avg. number of visitors');
title('Monthly averages');
set(gca,'XTick',1:12);
set(gca,'XTickLabel',['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', ...
                      'Aug', 'Sep', 'Oct', 'Nov', 'Dec']);

%% (C) What's the best time of day to go get coffee?

% get the minimum number of people that show up during the day,
% and find the time at which that happens
[peetsMinIndex peetsMinCount] = min(mean(peets,2));
peetsBestTime = t(peetsMinIndex);

[lkscMinIndex lkscMinCount] = min(mean(lksc,2));
lkscBestTime = t(lkscMinIndex);

% convert the time into a human readable format
if peetsBestTime > 12
    peetsString = [num2str(peetsBestTime-12) ':00 PM'];
else
    peetsString = [num2str(peetsBestTime) ':00 AM'];
end

if lkscBestTime > 12
    lkscString = [num2str(lkscBestTime-12) ':00 PM'];
else
    lkscString = [num2str(lkscBestTime) ':00 AM'];
end

% print the results
fprintf(['Best time for Peet''s coffee: ' peetsString ...
         ' (%.2f people on average)\n'], peetsMinCount);

fprintf(['Best time for LKSC coffee: ' lkscString ...
         ' (%.2f people on average)\n'], lkscMinCount);
