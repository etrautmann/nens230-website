%% Benford's Law example (still need to refactor ..)
%  ???
%
%  Created by: Niru Maheswaranathan
%  Created on: Mon Oct 15 11:27:41 2012
%
%  Edited by: ???
%  Edited on: ???

% Load population data (obtained from the CIA world factbook)
load populationData.mat
df = zeros(9,1);
d = 1:9;
for j = 1:length(population)
n = population(j);
while n >= 10
n = floor(n/10);
end
df(n) = df(n) + 1;
end
df = df./sum(df);
b = log10(1 + 1./(d));
figure(2); bar(d,df,'c'); hold on; plot(d, b, 'r*-'); xlabel('Digit'); ylabel('Frequency'); title('Benford''s Law applied to Country Populations');
legend('Data', 'Prediction'); legend boxoff; set(gca, 'TickDir', 'out', 'Box', 'Off');