function [binnedMat, binStarts, binEnds] = binSpikeTimes( spikeTimes, binSize, startTime, endT )
% binSpikeTimes.m
%
% Takes a list of spike times for one or more channels, from one or more
% trials, and returns a matrix of binned spike counts for each channel, summed
% across trials.
% NOTE: This function does not enforce units (e.g. ms or seconds) so it is
% up to the caller to verify that all arguments are in the same unit.
% NOTE 2: if (endT-startT) does not divide evenly by binT, then the last bin
% will be cut off (i.e. shorter than binT).
%
% USAGE:
%  binnedMat = binSpikeTimes( spikeTimes, binT, startT, endT )
%
% INPUTS:
%      spikeTimes    cell array containing vectors of spike times.
%                    Should be trials x chans
%      binT          time width of the bins.
%      startT        start time of first bin.
%      endT          end time of last bin
% OUTPUTS:
%      binnedMat     chan x bin matrix containing the number of spikes
%                    (averaged over trials) for a given channel and time bin.
%      binStarts     start time of each bin
%      binEnds       end time of each bin
% Created by Sergey Stavisky on 11 October 2011
% Edited by Sergey Stavisky on 15 October 2011
% Edited by Eric Trautmann on 14 October 2013 to transpose spikeTimes cell
%       array to be consistent with dataset format provided and to remove
%       solution code.
% Edited by Niru Maheswaranathan on 18 October 2013

% =============================================
% create two variables, numElectrodes and numTrials using your input
% arguement spikeTimes. numElectrodes should store the number of electrodes,
% numTrials should store the number of trials. Hint: You can get this info from
% the size of the spikeTimes cell array

temp=spikeTimes;
tempS=size(temp);
numTrials=tempS(1);numElectrodes=tempS(2);

% Define bin start and end times.
% 1) create variable binStarts - array of starting times for each bin
% 2) create variable binEnds - array of ending times for each bin
% 3) create variable numBins - number of total bins



numBins= 10;
binStarts=linspace(startTime,endT-binSize,numBins);
binEnds=linspace(startTime+binSize,endT,numBins);

% Preallocate output array binnedMat.  This is for efficienty, we'll talk
% more about preallocating arrays soon.
binnedMat = zeros( numBins, numElectrodes);

% Loop across all time bins and add up the spikes that fall within this
% bin. There are many ways to do this, use whatever you can think of!
% This is the meat of this function


for iBins=1:numBins
    bounds=[binStarts(iBins) binEnds(iBins)];
    for iChannel=1:numElectrodes
        tSpikes = 0;
        for iTrial = 1:numTrials
            tSpikes = tSpikes + sum(spikeTimes{iTrial, iChannel} > bounds(1) & spikeTimes{iTrial, iChannel} < bounds(2));
        end
        binnedMat(iBins, iChannel) = tSpikes;
    end
end


% Divide your binnedMat by number of trials to get average number of spikes/bin/trial

binnedMat=binnedMat./numTrials;