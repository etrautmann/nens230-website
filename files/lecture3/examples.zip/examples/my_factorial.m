function fact = my_factorial(num)
%% FUNCTION fact = my_factorial(num)
% NENS 230 Lecture 3
% Example looping function, compute the factorial of input 'num'

%% Initialize the factorial value
fact = 1;

%% Loop over each number from 'num' down to 2
for i = num : -1 : 2
    % In each iteration of the loop, 'i' decreases by 1. We multiply this
    % value by our current value of the factorial.
    fact = i * fact;
    
end

end