function [] = example2()
%% NENS 230 Lecture 3
% Example 1: If/else branching
% Determine if a number is even or odd.

% Use the 'input' function to get a number from the user.
num = input('Give me a number: ');

%% Print out the parity of the number, ODD or EVEN, which 
% we determine using the modulus of the number.
if is_even(num)
    fprintf('%d is EVEN\n', num);
    
else
    fprintf('%d is ODD\n', num);
end




end

%% Helper function returns 'true' if number is even.
function val = is_even(num)
    val = (mod(num, 2) == 0);
end
