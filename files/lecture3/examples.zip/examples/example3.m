function [] = example3()
% NENS 230 Example 2
% Example 2: If/elseif branching
% Determine if a given year is a leap year.

% Use the 'input' function to get a year from the user.
year = input('Please give me a year: ');

%% Determine if the given year is a leap year.
% Leap years must be a multiple of 4
if ~is_multiple(year, 4)
    fprintf('%d is common year\n', year);

    
% If it's not a multiple of 100, it has to be a leap year.
elseif ~is_multiple(year, 100)
    fprintf('%d is a leap year\n', year);
    

% If it's NOT a multiple of 400, it has be to be a common
% year.
elseif ~is_multiple(year, 400)
    fprintf('%d a common year\n', year);


    
% Anything else is a leap year.
else
    fprintf('%d is a leap year\n', year);
end

end

function [val] = is_multiple(num, base)
%% Returns true if 'num' is a multiple of 'base'
    val = (mod(num, base) == 0);
end