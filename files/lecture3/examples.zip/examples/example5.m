function [] = example5(num)
%% NENS 230 Lecture 3
% Example 3: Combining logical values
% Determine if a given number is divisible by 3 and 5

%% Check if 'num' is divisible by both 3 and 5
if (is_multiple(num, 3) && is_multiple(num, 5))
    fprintf('%d is div. by both\n', num);
    
    
% Every other number is dealt with here.
elseif is_multiple(num, 3)
    fprintf('%d is div. by 3\n', num);
    
elseif is_multiple(num, 5)
    fprintf('%d is div. by 5\n', num);
    
else
    fprintf('%d is not divisible\n', num);
end



end

%% Helper function, returns true if 'num' is divisible by 'base'
function val = is_multiple(num, base)
    val = (mod(num, base) == 0);
end