function [] = example4()
%% NENS 230 Lecture 3
% Example 5: Branching with switch/case
% Do example 1 over, but with switch/case

% Get a number from the user
num = input('Give me a numer: ');
val = is_even(num);

%% Determine if number is even or odd
% Use 'switch' keyword to start the block
switch num
    
    % Even numbers
    case 1
        fprintf('%d is even\n', num);
        
    % Odd numbers    
    case 0
        fprintf('%d is odd\n', num);
        
    % Are any numbers neither even nor odd?
    otherwise
        fprintf('you have broken math\n');
end

end

function val = is_even(num)
    val = (mod(num, 2) == 0);
end