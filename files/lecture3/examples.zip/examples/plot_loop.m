function fig = plot_loop()
%% FUNCTION fig = plot_loop()
% NENS 230 Lecture 3
% Example plotting function with loops

%% Total number of subplots
num_rows = 2;
num_columns = 2;

%% Construct a figure
fig = figure();

%% Plot random data on each subplot, using a loop
for i = 1:num_rows
    for j = 1:num_columns
        
        % Compute the linear plot number
        pi = sub2ind([num_rows num_columns], i, j);
        
        % Construct a subplot
        subplot(num_rows, num_columns, pi);
        
        % Plot random data
        plot(randn(20, 1))
        
        % Create a title showing the plot number, which is also the loop index
        title(sprintf('this is plot %d', pi));
    end
end
